import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart'; // Import FirebaseAuth for checking authentication
import 'screens/signup_page.dart';
import 'screens/login_page.dart';
import 'screens/user_dashboard.dart';
import 'screens/admin_dashboard.dart'; // Import AdminDashboard

void main() async {
  WidgetsFlutterBinding.ensureInitialized(); // Ensures all widgets are initialized before running the app

  if (kIsWeb) {
    await Firebase.initializeApp(
      options: const FirebaseOptions(
        apiKey: "AIzaSyBXv1fzrWPPKRUs1KPxfCkE2NAabEi46tM",
        authDomain: "project-9fa76.firebaseapp.com",
        projectId: "project-9fa76",
        storageBucket: "project-9fa76.firebasestorage.app",
        messagingSenderId: "946522686014",
        appId: "1:946522686014:web:d33d550cebdd352464076f",
        measurementId: "G-J3SZ8833QK",
      ),
    );
  } else {
    await Firebase.initializeApp();
  }

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'User Authentication',
      initialRoute: _initialRoute(),
      routes: {
        '/login': (context) => LoginPage(),
        '/signup': (context) => SignupPage(),
        '/dashboard': (context) {
          final args = ModalRoute.of(context)!.settings.arguments as Map<String, String>;
          return UserDashboard(name: args['name']!, email: args['email']!);
        },
        '/adminDashboard': (context) => AdminDashboard(), // Add AdminDashboard route
      },
    );
  }

  // Check if the user is already logged in and redirect accordingly
  String _initialRoute() {
    final user = FirebaseAuth.instance.currentUser;
    
    if (user != null) {
      // Check if the logged-in user is the admin
      if (user.email == 'admin@gmail.com') {
        return '/adminDashboard';
      } else {
        return '/dashboard';
      }
    }
    // Otherwise, go to the login page
    return '/login';
  }
}

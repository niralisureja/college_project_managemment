import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';

class UserDashboard extends StatefulWidget {
  final String name;
  final String email;

  const UserDashboard({super.key, required this.name, required this.email});

  @override
  _UserDashboardState createState() => _UserDashboardState();
}

class _UserDashboardState extends State<UserDashboard> {
  final List<Map<String, dynamic>> _tasks = [
    {
      'title': 'Project 1',
      'description': 'Submit project proposal',
      'dueDate': DateTime.now().add(Duration(days: 3)),
      'file': null, // File name or content
    },
    {
      'title': 'Project 2',
      'description': 'Submit final report',
      'dueDate': DateTime.now().add(Duration(days: 7)),
      'file': null, // File name or content
    },
  ];

  Future<void> _pickFile(int index) async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles();

      if (result != null) {
        // For web: use file name; for other platforms: path may be available.
        setState(() {
          _tasks[index]['file'] = result.files.single.name;
        });
        print("File selected for ${_tasks[index]['title']}: ${result.files.single.name}");
      } else {
        print("No file selected.");
      }
    } catch (e) {
      print("Error picking file: $e");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error selecting file: $e")),
      );
    }
  }

  void _submitTask(int index) {
    if (_tasks[index]['file'] == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please attach a file before submitting!")),
      );
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("${_tasks[index]['title']} submitted successfully!")),
    );

    setState(() {
      _tasks[index]['file'] = null; // Clear file after submission
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("User Dashboard")),
      drawer: Drawer(
        child: ListView(
          children: [
            UserAccountsDrawerHeader(
              accountName: Text(
                widget.name.isNotEmpty
                    ? widget.name
                    : widget.email.split('@')[0],
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              accountEmail: Text(widget.email),
              currentAccountPicture: CircleAvatar(
                backgroundImage: AssetImage('assets/profile_placeholder.png'),
              ),
              decoration: BoxDecoration(
                color: Colors.blue,
                image: DecorationImage(
                  image: AssetImage('assets/dashboard_background.jpg'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.person),
              title: Text("Profile"),
              onTap: () {
                // Navigate to Profile Screen
              },
            ),
            ListTile(
              leading: Icon(Icons.logout),
              title: Text("Logout"),
              onTap: () {
                Navigator.of(context).pushReplacementNamed('/login');
              },
            ),
          ],
        ),
      ),
      body: ListView.builder(
        itemCount: _tasks.length,
        itemBuilder: (context, index) {
          final task = _tasks[index];
          return Card(
            margin: const EdgeInsets.all(10.0),
            elevation: 4,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    task['title'],
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 5),
                  Text(task['description']),
                  SizedBox(height: 10),
                  Text(
                    "Due Date: ${task['dueDate'].toLocal()}".split(' ')[0],
                    style: TextStyle(color: Colors.grey[700]),
                  ),
                  SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          task['file'] != null
                              ? "Attached: ${task['file']}"
                              : "No file attached",
                          style: TextStyle(
                            fontStyle: task['file'] != null
                                ? FontStyle.normal
                                : FontStyle.italic,
                          ),
                        ),
                      ),
                      ElevatedButton(
                        onPressed: () => _pickFile(index),
                        child: Text("Attach File"),
                      ),
                    ],
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () => _submitTask(index),
                    child: Text("Submit Work"),
                    style: ElevatedButton.styleFrom(
                      minimumSize: Size(double.infinity, 50),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
